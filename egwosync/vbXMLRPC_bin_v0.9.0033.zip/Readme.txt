vbXMLRPC.dll version 0.9.0033 - 15th May, 2004

vbXMLRPC is an implementation of a COM XML-RPC client.

Written by Phil Hewitt (e-mail : support@enappsys.com)

Released under the GNU Lesser General Public License, see license file in package.

For further information go to http://www.enappsys.com/backend.jsp

Release Notes are at http://www.enappsys.com/backend/vbXMLRPC/vbXMLRPCReleaseNotes.jsp
Install Notes are at http://www.enappsys.com/backend/vbXMLRPC/vbXMLRPCInstallNotes.jsp
